create function pg_catalog.interval_pl_time(interval, time without time zone) returns time without time zone
LANGUAGE SQL
AS $$
select $2 + $1
$$;
